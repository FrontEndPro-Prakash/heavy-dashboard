$(function() {
    $("#range-slider")
    .slider({
        range: true,
        min: 0,
        max: 20,
        values: [1, 15],
        step: 1
    })
    .slider("float", {
        handle: true,
        pips: false,
        labels: false,
        prefix: "",
        suffix: "M"
    });
    $("#above-slider")
    .slider({
        min: 0,
        max: 20,
        values: [10],
        step: 1
    })
    .slider("float", {
        handle: true,
        pips: false,
        labels: false,
        prefix: "",
        suffix: "M"
    });
    $("#below-slider")
    .slider({
        min: 0,
        max: 20,
        values: [10],
        step: 1
    })
    .slider("float", {
        handle: true,
        pips: false,
        labels: false,
        prefix: "",
        suffix: "M"
    });
});

$(function() {
   var print = function(msg) {
     alert(msg);
   };

   var setInvisible = function(elem) {
     elem.css('display', 'block');
   };
   var setVisible = function(elem) {
     elem.css('display', 'block');
   };

   var elem = $("#elem");
   var items = elem.children();

   // Inserting Buttons
   elem.prepend('<div class="left-right-btn" id="right-button"><a href="#"><</a></div>');
   elem.append(' <div class="left-right-btn" id="left-button"><a href="#">></a></div>');

   // Inserting Inner
   items.wrapAll('<div id="inner" />');

   // Inserting Outer
   elem.find('#inner').wrap('<div id="outer"/>');

   var outer = $('#outer');

   var updateUI = function() {
     var maxWidth = outer.outerWidth(true);
     var actualWidth = 0;
     $.each($('#inner >'), function(i, item) {
       actualWidth += $(item).outerWidth(true);
     });

     if (actualWidth <= maxWidth) {
       setVisible($('#left-button'));
     }
   };
   updateUI();

   $('#right-button').click(function() {
     var leftPos = outer.scrollLeft();
     outer.animate({
       scrollLeft: leftPos - 200
     }, 800, function() {
       if ($('#outer').scrollLeft() <= 0) {
         setInvisible($('#right-button'));
       }
     });
   });

   $('#left-button').click(function() {
     setVisible($('#right-button'));
     var leftPos = outer.scrollLeft();
     outer.animate({
       scrollLeft: leftPos + 200
     }, 800);
   });

   $(window).resize(function() {
     updateUI();
   });
});



/*high chart js*/
Highcharts.chart('fpo_chart_type2', {
    chart: {
        zoomType: 'xy',
        marginTop: 60,
    },
    title: {
        text: null
    },
    subtitle: {
        text: null
    },
    colors: ['#f8981d', '#073949'],
    xAxis: [{
        categories: ['1', '2', '3', '4', '5', '6',
            '7', '8', '9', '10', '11'],
        crosshair: true
    }],
    yAxis: [{ // Primary yAxis
        min: 0,
   max: 15,
   tickInterval: 5,
        labels: {
            format: '{value}K'
        },
        title: {
            text: null,
        }
    }, { // Secondary yAxis
        title: {
            text: null,            
        },
        labels: {
        enabled: false,
        },
    }],
    tooltip: {
        shared: true,
        //enabled: false
    },
    credits: {
   enabled: false
 },
    legend: {
        align: 'left',
        x: -10,
        verticalAlign: 'top',
        y: 0,
        floating: true
    },
    plotOptions: {
  series: {
      dataLabels: {
        enabled: false
      },
      states: {
        inactive: {
        opacity: 1
        },
        hover: {
          enabled: false,
        }
      }
    }
  },
    series: [{
        name: 'No. of new FPOs',
        type: 'column',
        data: [5, 12, 11, 10, 9, 6, 8, 3, 8, 10, 8]

    }, {
        name: 'No. of Farmers',
        type: 'spline',
        data: [3, 5, 2, 6, 8, 3, 4, 1, 3, 6, 4]
    }]
});
/*high chart js*/